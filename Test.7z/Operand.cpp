#include "Operand.h"



Operand::Operand()
{
}

Operand::Operand(std::string value)
{
	strValue = value;
}

Operand::Operand(int value)
{
	intValue = value;
}

Operand::Operand()
{
}

Operand::~Operand()
{
}
